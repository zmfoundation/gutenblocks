// import './blocks/team-member/script';
import './blocks/info-card/script';
import './blocks/logo/script';
import './blocks/advanced-info-card/script';
import './blocks/table/script';
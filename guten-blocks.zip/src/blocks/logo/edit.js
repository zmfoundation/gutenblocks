import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, InspectorControls, BlockControls, MediaUploadCheck, MediaUpload, mediaUpload } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, ColorPalette, RangeControl, TextControl, IconButton, Toolbar } from '@wordpress/components';
// import { __ } from '@wordpress/i18n';

const colors = [
	{
		name: "Dark Green",
		color: "#008255"
	},
	{
		name: "White",
		color: "#ffffff"
	},
	{
		name: "Black",
		color: "#000000"
	}
];

class Edit extends Component {
    render() {
		const { className, attributes } = this.props;
		const { id, alt, url, btnText, siteInfo, btnColor, btnBg, btnSize, btnPadding, btnRadius, btnLink, logoLink } = attributes;
        return (
			<Fragment>
				<InspectorControls>
                    <PanelBody
                        title= "Logo Link"
                        initialOpen= { false }
                    >
                        <TextControl
                            label='Link'
                            value={ logoLink }
                            onChange={ ( logoLink ) => this.props.setAttributes( { logoLink } ) }
                        />
                    </PanelBody>
                    <PanelBody
                        title= "Button Link"
                        initialOpen= { false }
                    >
                        <TextControl
                            label='Link'
                            value={ btnLink }
                            onChange={ ( btnLink ) => this.props.setAttributes( { btnLink } ) }
                        />
                    </PanelBody>
                    <PanelBody
                        title= 'Button Styling'
                        initialOpen= { false }
                    >
                        <ColorPalette
                            title= "Text Color"
                            colors={ colors }
                            onChange={ ( btnColor ) => this.props.setAttributes( { btnColor } ) }
                            value={ btnColor }
                        />
                        <ColorPalette
                            label= "Background Color"
                            colors={ colors }
                            onChange={ ( btnBg ) => this.props.setAttributes( { btnBg } ) }
                            value={ btnBg }
                        />
                        <RangeControl
                            label= 'Font Size'
                            value={ btnSize }
                            onChange={ ( btnSize ) => this.props.setAttributes( { btnSize } ) }
                            min={ 1 }
                            max={ 100 }
                        />
                        <RangeControl
                            label= 'Padding'
                            value={ btnPadding }
                            onChange={ ( btnPadding ) => this.props.setAttributes( { btnPadding } ) }
                            min={ 1 }
                            max={ 100 }
                        />
                        <RangeControl
                            label= 'Border Radius'
                            value={ btnRadius }
                            onChange={ ( btnRadius ) => this.props.setAttributes( { btnRadius } ) }
                            min={ 0 }
                            max={ 50 }
                        />
                    </PanelBody>
				</InspectorControls>
                <BlockControls>
                    { url &&
                        <Toolbar>
                            { id &&
                                <MediaUploadCheck>
                                    <MediaUpload
                                        onSelect={ ({ id, url, alt })=> this.props.setAttributes( { id, url, alt } ) }
                                        allowedTypes={ ['image'] }
                                        value={ id }
                                        render={ ( { open } ) => (
                                            <IconButton
                                                icon="edit"
                                                label="Edit Logo"
                                                onClick={ open }
                                            />
                                        ) }
                                    />
                                </MediaUploadCheck>
                            }
                        </Toolbar>
                    }
                </BlockControls>
				<div className="wt_logo_block_container">
                    <div className="wt_site_logo">
                        { url ?
                                <>
                                    <a href={ logoLink } target="_self" rel="noopener noreferrer">
                                        <img src={ url } alt={ alt } />
                                    </a>
                                    {
                                        isBlobURL( { url } ) && 
                                        <Spinner/>
                                    }
                                </>
                            : 
                            <MediaPlaceholder
                                onSelect= { ({ id, url, alt })=> this.props.setAttributes( { id, url, alt } ) }
                                accept="image/*"
                                allowedTypes={ ['image'] }
                                labels = { { title: 'Upload Logo' } }
                            />
                        }
                    </div>
                    <a className="wt_logo_btn" href={ btnLink } target="_self" style={{ color: btnColor, backgroundColor: btnBg, fontSize: btnSize, borderRadius: btnRadius, paddingTop: btnPadding, paddingBottom: btnPadding, paddingLeft: 3*btnPadding, paddingRight: 3*btnPadding }} rel="noopener noreferrer">
                        <RichText
                            className={ className }
                            value={ btnText }
                            onChange={ ( btnText ) => this.props.setAttributes( { btnText } ) }
                            formattingControls={ ['bold'] }
                        />
                    </a>
                    <RichText
                        tagName="p"
                        className={ className }
                        value={ siteInfo }
                        onChange={ ( siteInfo ) => this.props.setAttributes( { siteInfo } ) }
                        formattingControls={ ['bold','italic'] }
                    />
				</div>
			</Fragment>
		)
    }
}

export default Edit;
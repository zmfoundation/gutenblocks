import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
// import { __ } from '@wordpress/i18n'; 
import { RichText } from '@wordpress/block-editor';

const attributes = {
    id: {
        type: 'number'
    },
    url: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'src'
    },
    alt: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'alt'
    },
    logoLink: {
        type: 'string',
        default: '#'
    },
    btnText: {
        type: 'string',
        default: 'LEARN MORE'
    },
    siteInfo: {
        type: 'string',
        source: 'html',
        selector: 'p',
        default: 'At Betterment'
    },
    btnLink: {
        type: 'string',
        default: '#'
    },
    btnColor: {
        type: 'string',
        default: '#ffffff'
    },
    btnBg: {
        type: 'string',
        default: '#008255'
    },
    btnSize: {
        type: 'number',
        default: 14
    },
    btnPadding: {
        type: 'number',
        default: 6
    },
    btnRadius: {
        type: 'number',
        default: 0
    },
    btnLink: {
        type: 'string',
        default: '#'
    }
};

registerBlockType( 'wt-block/logo', {
    title: 'Logo', 
    description: 'Logo Display Block',
    category: 'custom-blocks',
    icon: {
        src: <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M11 4.07V2.05c-2.01.2-3.84 1-5.32 2.21L7.1 5.69c1.11-.86 2.44-1.44 3.9-1.62zm7.32.19C16.84 3.05 15.01 2.25 13 2.05v2.02c1.46.18 2.79.76 3.9 1.62l1.42-1.43zM19.93 11h2.02c-.2-2.01-1-3.84-2.21-5.32L18.31 7.1c.86 1.11 1.44 2.44 1.62 3.9zM5.69 7.1L4.26 5.68C3.05 7.16 2.25 8.99 2.05 11h2.02c.18-1.46.76-2.79 1.62-3.9zM4.07 13H2.05c.2 2.01 1 3.84 2.21 5.32l1.43-1.43c-.86-1.1-1.44-2.43-1.62-3.89zM15 12c0-1.66-1.34-3-3-3s-3 1.34-3 3 1.34 3 3 3 3-1.34 3-3zm3.31 4.9l1.43 1.43c1.21-1.48 2.01-3.32 2.21-5.32h-2.02c-.18 1.45-.76 2.78-1.62 3.89zM13 19.93v2.02c2.01-.2 3.84-1 5.32-2.21l-1.43-1.43c-1.1.86-2.43 1.44-3.89 1.62zm-7.32-.19C7.16 20.95 9 21.75 11 21.95v-2.02c-1.46-.18-2.79-.76-3.9-1.62l-1.42 1.43z"/></svg>
    },
    keywords: [
        'Logo',
        'Site Logo'
    ],
    supports: {
        html: false, 
        align: true
    },
    attributes,
    edit: Edit,
    save: ( { className, attributes } ) => {
            const { id, url, alt, logoLink, btnLink, btnColor, btnBg, btnSize, btnRadius, btnText, btnPadding, siteInfo } = attributes;
        return(
                <div className="wt_logo_block_container">
                    <div className="wt_site_logo">
                        <a href={ logoLink } target="_blank" rel="noopener noreferrer">
                            <img src={ url } alt={ alt } className={ id ? `wp-image-${id}` : null } />
                        </a>
                    </div>
                    <a className="wt_logo_btn" href={ btnLink } target="_blank" style={{ color: btnColor, backgroundColor: btnBg, fontSize: btnSize, borderRadius: btnRadius, paddingTop: btnPadding, paddingBottom: btnPadding, paddingLeft: 3*btnPadding, paddingRight: 3*btnPadding }} rel="noopener noreferrer">
                        <RichText.Content
                            className={ className }
                            value={ btnText }
                        />
                    </a>
                    <RichText.Content
                        tagName="p"
                        className={ className }
                        value={ siteInfo }
                    />
				</div>
        )
    }
});
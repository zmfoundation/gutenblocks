import './style.scss';

import $ from 'jquery';

$(document).on('click', '.wt_adv_collapse_btn', function(){
    $('.wt_adv_collapse_content').toggle(100);

    $('.wt_adv__btn').toggleClass('active');

});


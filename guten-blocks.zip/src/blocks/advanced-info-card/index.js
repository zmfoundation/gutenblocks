import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
// import { __ } from '@wordpress/i18n'; 
import { InnerBlocks, RichText } from '@wordpress/editor';

const attributes = {
	alt: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'alt',
	},
	url: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'src',
	},
	id: {
        type: 'number',
	},
	btnText: {
		type: 'string',
		default: 'OPEN ACCOUNT'
	},
	siteInfo: {
		type: 'string',
		default: 'On Blooom Website',
	},
	logoText: {
		type: 'string',
		default: 'BLOOM'
	},
	rating: {
		type: 'string',
		default: 'Rating: 5'
	},
	borderColor: {
		type: 'string',
		default: '#efefef'
	},
	borderWidth: {
		type: 'number'
	},
	titleSize: {
		type: 'number',
		default: 24
	},
	footerCols: {
		type: 'number',
		default: 2
	},
	btnUrl: {
		type: 'string',
		default: '#'
	},
	btnPadding: {
		type: 'number',
		default: 8
	},
	btnRadius: {
		type: 'number',
		default: 0
	},
	btnTextColor: {
		type: 'string',
		default: '#ffffff'
	},
	btnBgColor: {
		type: 'string',
		default: '#008255'
	},
	infoPrice1: {
		type: 'string',
		default: '$120'
	},
	infoTitle1: {
		type: 'string',
		default: 'FEES'
	},
	infoPlan1: {
		type: 'string',
		default: 'Per Year'
	},
	infoPrice2: {
		type: 'string',
		default: '$120'
	},
	infoTitle2: {
		type: 'string',
		default: 'FEES'
	},
	infoPlan2: {
		type: 'string',
		default: 'Per Year'
	},
	infoPrice3: {
		type: 'string',
		default: '$120'
	},
	infoTitle3: {
		type: 'string',
		default: 'FEES'
	},
	infoPlan3: {
		type: 'string',
		default: 'Per Year'
	}
};

registerBlockType( 'wt-block/advanced-info-card', {
	title: 'Advanced Info Card', 
	description: 'Display information',
	category: 'custom-blocks',
	icon: {
		src: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="black" width="18px" height="18px"><path d="M0 0h24v24H0z" fill="none"/><path d="M10.85 12.65h2.3L12 9l-1.15 3.65zM20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zM14.3 16l-.7-2h-3.2l-.7 2H7.8L11 7h2l3.2 9h-1.9z"/></svg>,
	},
	keywords: [
		'Info Box',
		'Info Card', 
		'Information Box'
	],
	attributes,
	edit: Edit,
	save: ( { className, attributes } ) => {
		const { url, alt, btnText, siteInfo, logoText, rating, footerCols, titleSize, borderColor, borderWidth, btnUrl, btnPadding, btnRadius, btnTextColor, btnBgColor, infoTitle1, infoPrice1, infoPlan1, infoTitle2, infoPrice2, infoPlan2, infoTitle3, infoPrice3, infoPlan3 } = attributes; 
		return(
			<div className="wt_adv_info_box_container" style={ { borderColor: borderColor, borderWidth: borderWidth } }>
				<div className="wt_adv_info_box_visiable">
					<div className="wt_adv_info_box_action_area">
						<div className="wt_adv_site_logo">
							{ url &&
								<img src={ url } alt={ alt } />
							}
						</div>
						<a className="wt_adv_action_btn" href={ btnUrl } target="_blank" rel="noopener noreferrer" style={ { borderRadius: btnRadius, paddingTop: btnPadding, paddingBottom: btnPadding, paddingLeft: 2*btnPadding, paddingRight: 2*btnPadding, color: btnTextColor, backgroundColor: btnBgColor } }>
							<RichText.Content
								className={ className }
								value={ btnText }
							/>
						</a>
						<RichText.Content
							tagName="p"
							className={ className }
							value={ siteInfo }
						/>
					</div>
					<div className="wt_adv_info_box_content_area">
						<div className="wt_adv_content_head">
							<div className="wt_adv_logo_title" style={ { fontSize: titleSize } }>
								<RichText.Content
									value={ logoText }
								/>
							</div>
							<div className="wt_adv_header_rating">
								<RichText.Content
									value={ rating }
								/>
							</div>
						</div>
					</div>
					<div className="wt_adv_price_area">
						<div className={ `wt_adv_content_footer has-${footerCols}-cols` }>
							<div className="wt_adv_single_content">
								<RichText.Content
									tagName="h5"
									className= { className }
									value={ infoTitle1 }
								/>
								<RichText.Content
									tagName="p"
									value={ infoPrice1 }
									className= { className }
								/>
								<RichText.Content
									tagName="p"
									className= { className }
									value={infoPlan1 }
								/>
							</div>
							<div className="wt_adv_single_content">
								<RichText.Content
									tagName="h5"
									className= { className }
									value={ infoTitle2 }
								/>
								<RichText.Content
									tagName="p"
									value={ infoPrice2 }
									className= { className }
								/>
								<RichText.Content
									tagName="p"
									className= { className }
									value={infoPlan2 }
								/>
							</div>
							<div className="wt_adv_single_content">
								<RichText.Content
									tagName="h5"
									className= { className }
									value={ infoTitle3 }
								/>
								<RichText.Content
									tagName="p"
									value={ infoPrice3 }
									className= { className }
								/>
								<RichText.Content
									tagName="p"
									className= { className }
									value={infoPlan3 }
								/>
							</div>
						</div>
					</div>
				</div>
				<div className="wt_adv_collapse_area">
					<div className="wt_adv_collapse_btn">
						<div className="wt_adv__btn active">
							See Details 
							<span class="dashicons dashicons-arrow-down-alt2"></span>
						</div>
						<div className="wt_adv__btn">
							Hide Details 
							<span class="dashicons dashicons-arrow-up-alt2"></span>
						</div>
					</div>
					<div className="wt_adv_collapse_content">
						<InnerBlocks.Content />
					</div>
				</div>
			</div>
		)
	}
});
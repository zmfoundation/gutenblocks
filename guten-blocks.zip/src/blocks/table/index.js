import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
// import { __ } from '@wordpress/i18n'; 
import { InnerBlocks, RichText } from '@wordpress/editor';

const attributes = {
	thOffer: {
		type: 'string',
		default: 'OFFER',
	},
	thRate: {
		type: 'string',
		default: 'APY',
	},
	thDesc: {
		type: 'string',
		default: 'BEST FOR',
	},
	thAction: {
		type: 'string',
		default: 'NEXT STEPS',
	},
	alt: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'alt',
	},
	url: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'src',
	},
	id: {
        type: 'number',
	},
	btnText: {
		type: 'string',
		default: 'OPEN ACCOUNT'
	},
	siteInfo: {
		type: 'string',
		default: 'On Blooom Website',
	},
	logoText: {
		type: 'string',
		default: 'BLOOM'
	},
	rating: {
		type: 'string',
		default: 'Rating: 5'
	},
	borderColor: {
		type: 'string',
		default: '#efefef'
	},
	borderWidth: {
		type: 'number'
	},
	titleSize: {
		type: 'number',
		default: 24
	},
	footerCols: {
		type: 'number',
		default: 3
	},
	btnUrl: {
		type: 'string',
		default: '#'
	},
	btnPadding: {
		type: 'number',
		default: 8
	},
	btnRadius: {
		type: 'number',
		default: 0
	},
	btnTextColor: {
		type: 'string',
		default: '#ffffff'
	},
	btnBgColor: {
		type: 'string',
		default: '#008255'
	},
};

registerBlockType( 'wt-block/table', {
	title: 'Simple Table', 
	description: 'Display information in Table',
	category: 'custom-blocks',
	icon: 'grid-view',
	keywords: [
		'Table',
		'Grid View', 
		'Table Info'
	],
	attributes,
	edit: Edit,
	save: ( { className, attributes } ) => {
		const { thOffer, thRate, thDesc, thAction } = attributes; 
		return(
			<div className="wt_table_container">
				<div className="wt_table_head">
					<div className="wt_th_offer">
						<RichText.Content
							tagName="strong"
							className={ className }
							value={ thOffer }
						/>
					</div>
					<div className="wt_th_apy">
						<RichText.Content
							tagName="strong"
							className={ className }
							value={ thRate }
						/>
					</div>
					<div className="wt_th_desc">
						<RichText.Content
							tagName="strong"
							className={ className }
							value={ thDesc }
						/>
					</div>
					<div className="wt_th_action">
						<RichText.Content
							tagName="strong"
							className={ className }
							value={ thAction }
						/>
					</div>
				</div>
				<div className="wt_table_body_container">
					<InnerBlocks.Content />
				</div>
			</div>
		)
	}
});
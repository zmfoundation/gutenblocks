import './child';
// import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { RichText, InnerBlocks, InspectorControls } from '@wordpress/editor';
import { PanelBody, ColorPalette, RangeControl } from '@wordpress/components';

const colors = [
	{
		name: "Dark Green",
		color: "#008255"
	},
	{
		name: "White",
		color: "#ffffff"
	},
	{
		name: "Black",
		color: "#000000"
	}
];

class Edit extends Component {
    render() {
		const { className, attributes } = this.props;
		const { thOffer, thRate, thDesc, thAction } = attributes;
        return (
			<Fragment>
                <InspectorControls>        

                </InspectorControls>
				<div className="wt_table_container" style={ {  } }>
                    <div className="wt_table_head">
                        <div className="wt_th_offer">
                            <RichText
                                tagName="strong"
                                className={ className }
                                value={ thOffer }
                                onChange={ ( thOffer ) => this.props.setAttributes( { thOffer } ) }
                                formattingControls={ ['italic'] }
                            />
                        </div>
                        <div className="wt_th_apy">
                            <RichText
                                tagName="strong"
                                className={ className }
                                value={ thRate }
                                onChange={ ( thRate ) => this.props.setAttributes( { thRate } ) }
                                formattingControls={ ['italic'] }
                            />
                        </div>
                        <div className="wt_th_desc">
                            <RichText
                                tagName="strong"
                                className={ className }
                                value={ thDesc }
                                onChange={ ( thDesc ) => this.props.setAttributes( { thDesc } ) }
                                formattingControls={ ['italic'] }
                            />
                        </div>
                        <div className="wt_th_action">
                            <RichText
                                tagName="strong"
                                className={ className }
                                value={ thAction }
                                onChange={ ( thAction ) => this.props.setAttributes( { thAction } ) }
                                formattingControls={ ['italic'] }
                            />
                        </div>
                    </div>
                    <div className="wt_table_body_container">
                        <InnerBlocks
                            allowedBlocks={ ['wt-block/table-row'] }
                            template= {[
                                ["wt-block/table-row"]
                            ]}
                        />
                    </div>
                </div>
			</Fragment>
		)
    }
}

export default Edit;
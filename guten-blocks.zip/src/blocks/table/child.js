// import { __ } from '@wordpress/i18n';
import { isBlobURL } from '@wordpress/blob';
import { registerBlockType } from '@wordpress/blocks';
import { RichText, MediaPlaceholder, BlockControls, MediaUpload, MediaUploadCheck, InspectorControls } from '@wordpress/editor';
import { Fragment } from 'react';
import { Toolbar, IconButton, PanelBody, ColorPalette, RangeControl, TextControl } from '@wordpress/components';

const attributes = {
    url: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'src'
    },
    alt: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'alt'
    },
    id: {
        type: 'number',
    },
    rating: {
        type: 'string',
        default: 'Rating: 5.0'
    },
    logoText: {
        type: 'string',
        default: 'CIT Bank Savings Builder'
    },
    siteInfo: {
        type: 'string',
        default: 'Member, FDIC'
    },
    rate: {
        type: 'string',
        default: '1.70%'
    },
    desc: {
        type: 'string',
        default: 'Limited time cash sign up bonus & high APY. Use code SPRING20 when applying to qualify'
    },
    btnText: {
        type: 'string',
        default: 'Apply Now'
    },
    textLogoColor: {
        type: 'string',
        default: '#AC145A'
    },
    textLogoSize: {
        type: 'number',
        default: 16
    },
    textInfoColor: {
        type: 'string',
        default: '#8a8c8e'
    },
    ratingSize: {
        type: 'number',
        default: 12
    },
    btnColor: {
        type: 'string',
        default: '#ffffff'
    },
    btnBg: {
        type: 'string',
        default: '#007A33'
    },
    btnPadding: {
        type: 'number',
        default: 8
    },
    btnBorderWidth: {
        type: 'number',
        default: 2
    },
    btnBorderColor: {
        type: 'string',
        default: '#007A33'
    },
    btnBorderRadius: {
        type: 'number',
        default: 3
    }, 
    rateOffset: {
        type: 'number',
        default: 45
    },
    btnOffset: {
        type: 'number',
        default: 45
    },
    textLogoOffset: {
        type: 'number',
        default: 10
    },
    descOffset: {
        type: 'number',
        default: 20
    },
    btnLink: {
        type: 'string',
        default: '#'
    }
}

const colors = [
	{
		name: "Dark Green",
		color: "#007A33"
	},
	{
		name: "White",
		color: "#ffffff"
	},
	{
		name: "Black",
		color: "#000000"
	}
];

registerBlockType('wt-block/table-row', {
    title: 'Simple Table Single Row',
    description: 'Acts as single row for Simple Table Block',
    icon: 'editor-insertmore',
    category: 'custom-blocks',
    supports: {
        reusable: false,
        html: false
    },
    attributes,
    edit: ({ className, attributes, setAttributes }) => {
        const { url, id, alt, rating, logoText, siteInfo, rate, desc, btnText, textLogoColor, textLogoSize,textInfoColor, ratingSize, btnColor, btnBg, btnPadding, btnBorderWidth, btnBorderColor, btnBorderRadius, rateOffset, btnOffset, textLogoOffset, descOffset, btnLink } = attributes; 
        return (
            <Fragment>   
                <InspectorControls>        
                    <PanelBody
                        initialOpen={ false }
                        title= "Text Logo Style"
                    >
                        <ColorPalette
                            colors={ colors }
                            onChange={ ( textLogoColor ) => setAttributes( { textLogoColor } ) }
                            value={ textLogoColor }
                        />
                        <RangeControl
                            label='Font Size'
                            value={ textLogoSize }
                            onChange={ ( textLogoSize ) => setAttributes( { textLogoSize } ) }
                            min={ 2 }
                            max={ 100 }
                        />
                    </PanelBody>
                    <PanelBody
                        title='Text Info Style'
                        initialOpen={ false }
                    >
                        <ColorPalette
                            colors={ colors }
                            onChange={ ( textInfoColor ) => setAttributes( { textInfoColor } ) }
                            value={ textInfoColor }
                        />
                    </PanelBody>
                    <PanelBody
                        title='Rating Font Size'
                        initialOpen={ false }
                    >
                        <RangeControl
                            label='Font Size'
                            value={ ratingSize }
                            onChange={ ( ratingSize ) => setAttributes( { ratingSize } ) }
                            min={ 2 }
                            max={ 50 }
                        />
                    </PanelBody>
                    <PanelBody
                        title='Button Style'
                        initialOpen={ false }
                    >
                        <ColorPalette
                            colors={ colors }
                            onChange={ ( btnColor ) => setAttributes( { btnColor } ) }
                            value={ btnColor }
                        />
                        <ColorPalette
                            colors={ colors }
                            onChange={ ( btnBg ) => setAttributes( { btnBg } ) }
                            value={ btnBg }
                        />
                        <RangeControl
                            label='Padding'
                            value={ btnPadding }
                            onChange={ ( btnPadding ) => setAttributes( { btnPadding } ) }
                            min={ 2 }
                            max={ 100 }
                        />
                        <RangeControl
                            label='Border Width'
                            value={ btnBorderWidth }
                            onChange={ ( btnBorderWidth ) => setAttributes( { btnBorderWidth } ) }
                            min={ 0 }
                            max={ 50 }
                        />
                        <RangeControl
                            label='Border Radius'
                            value={ btnBorderRadius }
                            onChange={ ( btnBorderRadius ) => setAttributes( { btnBorderRadius } ) }
                            min={ 0 }
                            max={ 50 }
                        />
                        <ColorPalette
                            colors={ colors }
                            onChange={ ( btnBorderColor ) => setAttributes( { btnBorderColor } ) }
                            value={ btnBorderColor }
                        />
                    </PanelBody>
                    <PanelBody
                        title='Button Link'
                        initialOpen= { false }
                    >
                        <TextControl
                            value={ btnLink }
                            onChange={ ( btnLink ) => setAttributes( { btnLink } ) }
                        />
                    </PanelBody>
                    <PanelBody
                        title='Offset Setting'
                        initialOpen= { false }
                    >
                        <RangeControl
                            label='Text Logo Top Offset'
                            value={ textLogoOffset }
                            onChange={ ( textLogoOffset ) => setAttributes( { textLogoOffset } ) }
                            min={ 0 }
                            max={ 100 }
                        />
                        <RangeControl
                            label='Rate Top Offset'
                            value={ rateOffset }
                            onChange={ ( rateOffset ) => setAttributes( { rateOffset } ) }
                            min={ 1 }
                            max={ 200 }
                        />
                        <RangeControl
                            label='Description Top Offset'
                            value={ descOffset }
                            onChange={ ( descOffset ) => setAttributes( { descOffset } ) }
                            min={ 0 }
                            max={ 200 }
                        />
                        <RangeControl
                            label='Button Top Offset'
                            value={ btnOffset }
                            onChange={ ( btnOffset ) => setAttributes( { btnOffset } ) }
                            min={ 1 }
                            max={ 200 }
                        />
                    </PanelBody>

                </InspectorControls>
                <BlockControls>
                    { url &&
                        <Toolbar>
                            { id &&
                                <MediaUploadCheck>
                                    <MediaUpload
                                        onSelect={ ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
                                        allowedTypes={ ['image'] }
                                        value={ id }
                                        render={ ( { open } ) => (
                                            <IconButton
                                                icon="edit"
                                                label="Edit Logo"
                                                onClick={ open }
                                            />
                                        ) }
                                    />
                                </MediaUploadCheck>
                            }
                        </Toolbar>
                    }
                </BlockControls>
                <div className="wt_tb_single_row">
                    <div className="wt_tb_brand">
                        <div className="wt_tb_brand_logo">
                            { url ?
                                    <>
                                        <img src={ url } alt={ alt } />
                                        {
                                            isBlobURL( { url } ) && 
                                            <Spinner/>
                                        }
                                    </>
                                : 
                                <MediaPlaceholder
                                    onSelect= { ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
                                    // onSelectURL={ (url)=> setAttributes( { url, id: null, alt: '' } ) }
                                    accept="image/*"
                                    allowedTypes={ ['image'] }
                                />
                            }
                            <div className="wt_star_rating" style={{ fontSize: ratingSize }}>
                                <RichText
                                    // tagName=""
                                    className={ className }
                                    value={ rating }
                                    onChange={ ( rating ) => setAttributes( { rating } ) }
                                    formattingControls={ ['bold','italic'] }
                                />
                            </div>
                        </div>
                        <div className="wt_tb_brand_txt">
                            <div className="wt_tb_brand_name" style={{ fontSize: textLogoSize, paddingTop: textLogoOffset }}>
                                <RichText
                                    className={ className }
                                    value={ logoText }
                                    onChange={ ( logoText ) => setAttributes( { logoText } ) }
                                    formattingControls={ ['bold','italic'] }
                                    style= { { color: textLogoColor } }
                                />
                            </div>
                            <RichText
                                className={ className }
                                value={ siteInfo }
                                onChange={ ( siteInfo ) => setAttributes( { siteInfo } ) }
                                formattingControls={ ['bold','italic'] }
                                style={{ color: textInfoColor }}
                            />
                        </div>
                    </div>
                    <div className="wt_tb_rate" style={{ paddingTop: rateOffset }}>
                        <RichText
                            className={ className }
                            value={ rate }
                            onChange={ ( rate ) => setAttributes( { rate } ) }
                            formattingControls={ ['bold','italic'] }
                        />
                    </div>
                    <div className="wt_tb_desc" style={{ paddingTop: descOffset }}>
                        <RichText
                            className={ className }
                            value={ desc }
                            onChange={ ( desc ) => setAttributes( { desc } ) }
                            formattingControls={ ['bold','italic'] }
                        />
                    </div>
                    <div className="wt_tb_btn" style={{ paddingTop: btnOffset }}>
                        <a href={ btnLink } style={{ color: btnColor, backgroundColor: btnBg, paddingTop: btnPadding, paddingBottom: btnPadding, paddingLeft: 2*btnPadding, paddingRight: 2*btnPadding, borderWidth: btnBorderWidth, borderRadius: btnBorderRadius, borderColor: btnBorderColor }} rel="noopener noreferrer">
                            <RichText
                                className={ className }
                                value={ btnText }
                                onChange={ ( btnText ) => setAttributes( { btnText } ) }
                                formattingControls={ ['italic'] }
                            />
                        </a>
                    </div>
                </div>
            </Fragment>
        )
    },
    save: ({ attributes, className }) => {
        const { url, id, alt, rating, logoText, siteInfo, rate, desc, btnText, textLogoColor, textLogoSize,textInfoColor, ratingSize, btnColor, btnBg, btnPadding, btnBorderWidth, btnBorderColor, btnBorderRadius, rateOffset, btnOffset, textLogoOffset, descOffset, btnLink } = attributes;
        return (
            <div className="wt_tb_single_row">
                <div className="wt_tb_brand">
                    <div className="wt_tb_brand_logo">
                        <img src={ url } alt={ alt } />
                        <div className="wt_start_rating" style={{ fontSize: ratingSize }} >
                            <RichText.Content
                                // tagName=""
                                className={ className }
                                value={ rating }
                            />
                        </div>
                    </div>
                    <div className="wt_tb_brand_txt">
                        <div className="wt_tb_brand_name" style={{ fontSize: textLogoSize, paddingTop: textLogoOffset }}>
                            <RichText.Content
                                className={ className }
                                value={ logoText }
                                style= { { color: textLogoColor } }
                            />
                        </div>
                        <RichText.Content
                            className={ className }
                            value={ siteInfo }
                            style={{ color: textInfoColor }}
                        />
                    </div>
                </div>
                <div className="wt_tb_rate" style={{ paddingTop: rateOffset }}>
                    <RichText.Content
                        className={ className }
                        value={ rate }
                    />
                </div>
                <div className="wt_tb_desc" style={{ paddingTop: descOffset }}>
                    <RichText.Content
                        className={ className }
                        value={ desc }
                    />
                </div>
                <div className="wt_tb_btn" style={{ paddingTop: btnOffset }}>
                    <a href={ btnLink } target="_blank" style={{ color: btnColor, backgroundColor: btnBg, paddingTop: btnPadding, paddingBottom: btnPadding, paddingLeft: 2*btnPadding, paddingRight: 2*btnPadding, borderWidth: btnBorderWidth, borderRadius: btnBorderRadius, borderColor: btnBorderColor }} rel="noopener noreferrer">
                        <RichText.Content
                            className={ className }
                            value={ btnText }
                        />
                    </a>
                </div>
            </div>
        )
    }
})
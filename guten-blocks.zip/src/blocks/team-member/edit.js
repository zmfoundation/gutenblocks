import { Component, Fragment } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { RichText, MediaPlaceholder, BlockControls, MediaUpload, MediaUploadCheck } from '@wordpress/editor';
import { Toolbar, IconButton } from '@wordpress/components';

class TeamMember extends Component {
    render() {
        const { attributes, className } = this.props;
        const { title, info, url, alt, id } = attributes;

        const onChangleTitle = (title) => {
            this.props.setAttributes({title})
        }
        const onChangleBio = (info) => {
            this.props.setAttributes({info})
        }

        const onSelectImg = ( imgInfo ) => {
            this.props.setAttributes( {
                url: imgInfo.url,
                alt: imgInfo.alt,
                id: imgInfo.id
            } )
        }

        return (
            <Fragment>
                <BlockControls>
                    { url &&
                        <Toolbar>
                            <IconButton
                                icon="trash"
                                label="Remove"
                                onClick={()=> {
                                    this.props.setAttributes({ 
                                        url: null,
                                        alt: null,
                                        id: null
                                    })
                                }}
                            />
                        </Toolbar>
                    }
                    { url &&
                        <Toolbar>
                            { id &&
                                <MediaUploadCheck>
                                    <MediaUpload
                                        onSelect={ onSelectImg }
                                        allowedTypes={ ['image'] }
                                        value={ id }
                                        render={ ( { open } ) => (
                                            <IconButton
                                                icon="edit"
                                                label="Edit"
                                                onClick={ open }
                                            />
                                        ) }
                                    />
                                </MediaUploadCheck>
                            }
                        </Toolbar>
                    }
                </BlockControls>
                <div className= { className } >
                    { url ?
                        <>
                            <img src={ url } alt={ alt } />
                        </>
                    :
                        <MediaPlaceholder 
                            onSelect = { onSelectImg }
                            allowedTypes = { [ 'image' ] }
                            multiple = { false }
                            labels = { { title: 'Team Member Photo' } } 
                        />
                    }
                    <RichText
                        tagName="h4"
                        className={ 'team_member_title' }
                        value={ title }
                    onChange={ onChangleTitle }
                    placeholder= 'Member title'
                    formattingControls= { [] }
                    />
                    <RichText
                        tagName="p"
                        className={ 'team_member_bio' }
                        value={ info }
                    onChange={ onChangleBio }
                    placeholder= 'Member title'
                    />
                </div>
            </Fragment>
        )
    }
}
export default TeamMember; 

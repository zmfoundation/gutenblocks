import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { InnerBlocks, InspectorControls } from '@wordpress/editor';
import { PanelBody, RangeControl } from '@wordpress/components';

const attributes = {
    columns: {
        type: 'number',
        default: '2'
    }
}

registerBlockType('wt-block/team-members', {
    title: 'Team Members',
    description: 'Team members collection',
    icon: 'grid-view',
    category: 'custom-blocks',
    supports: {
        html: false
    },
    attributes,
    edit: ({ className, attributes, setAttributes }) => {
        const { columns } = attributes;
        return (
            <div className={ `${className} has-${columns}-columns` }>
                <InspectorControls>
                    <PanelBody
                        title="Columns Number"
                    >
                        <RangeControl
                            label="Columns"
                            value={ columns }
                            onChange={ (columns)=> setAttributes( { columns } ) }
                            max='6'
                            min='1'
                        />
                    </PanelBody>
                </InspectorControls>
                <InnerBlocks
                     allowedBlocks={ ['wt-block/team-member'] }
                     template= {[
                         ['wt-block/team-member'],
                         ['wt-block/team-member']
                     ]}
                />
            </div>
        )
    },
    save: ({ attributes, className, setAttributes }) =>{
        const { columns } = attributes;
        return (
            <div className={ `${className} has-${columns}-columns` }>
                <InnerBlocks.Content/>
            </div>
        )
    }
})
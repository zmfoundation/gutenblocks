import './style.editor.scss';
import './parent';
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import { RichText } from '@wordpress/editor';
import edit from './edit';

const attributes = {
    title: {
        type: 'string',
        source: 'html',
        selector: 'h4'
    },
    info: {
        type: 'string',
        source: 'html',
        selector: 'p'
    },
    url: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'src'
    },
    alt: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'alt'
    },
    id: {
        type: 'number'
    }
}

registerBlockType('wt-block/team-member', {
    title: 'Team Member',
    icon: 'admin-users',
    description: 'Simple team building block',
    category: 'custom-blocks',
    keywords: ['Team', 'Team member'],
    supports: {
        reusable: false,
        html: false
    },
    attributes,
    edit,
    save: ( { attributes, className } ) => {
        const { title, info, url, alt, id } = attributes;
        return (
            <div className= { className } >
                { url &&
                   <>
                        <img src={ url } alt={ alt } className={ id ? `wp-image-${id}` : null } />
                   </> 
                }
                <RichText.Content
                    tagName="h4"
                    className={ 'team_member_title' }
                    value={ title }
                />
                <RichText.Content
                    tagName="p"
                    className={ 'team_member_bio' }
                    value={ info }
                />
            </div>
        )
    }
});
<?php
/**
 * @package Guten Blocks
 * Plugin name: Guten Blocks
 * Author: Zakaria Binsaifullah
 * Author URI: https://about.me/zakaria_binsaifullah
 * Description: Guten Blocks include a set of custom Gutenberg Blocks that help to design the webpage easily and make it professional.
 * Version: 1.0.0
 * Text-domain: guten-blocks
 */

if (! defined('ABSPATH')) {
	exit();
}

/**	 
 * Custom Block Category
 */
function gtb_custom_cats($cats){
	return array_merge(
		$cats,
		array(
			array(
				'slug'=> 'custom-blocks',
				'title'=> 'Custom Blocks'
			)
		)
	);
}
add_filter( 'block_categories', 'gtb_custom_cats', 10, 2 );

 /**
  * my_block_register_blocks
  *
  * @param  mixed $block_name
  * @param  mixed $options
  * @return void
  */
  
 function gtb_register_blocks( $block_name, $options= array() ){
	register_block_type(
		'wt-block/' . $block_name,
		array_merge(
			array(
				'editor_script' => 'blocks-script',
				'editor_style'  => 'blocks-style',
				'script'        => 'blocks-front-script',
				'style'         => 'blocks-front-style'
			),
			$options
		)
	);
 }

/**
 * wt_blocks
 *
 * @return void
 */
function wt_blocks(){
	/**
	 * Blocks Scripts
	 */
	wp_register_script( 'blocks-script', plugins_url( 'dist/editor.js', __FILE__ ), array( 'wp-blocks','wp-i18n', 'wp-editor', 'wp-components', 'wp-element', 'wp-blob' ));

	// Front End Script 
	wp_register_script( 'blocks-front-script', plugins_url( 'dist/script.js', __FILE__ ), array('jquery'));


	wp_register_style( 'blocks-style', plugins_url( 'dist/editor.css', __FILE__ ), array( 'wp-edit-blocks' ));

	// Front End Style
	wp_register_style( 'blocks-front-style', plugins_url( 'dist/style.css', __FILE__ ), array());

	/**
	 * Blocks Registration 
	 */
	// gtb_register_blocks( 'team-member' );
	// gtb_register_blocks( 'team-members' );
	gtb_register_blocks( 'info-card' );
	gtb_register_blocks( 'info-card-price' );
	gtb_register_blocks( 'logo' );
	gtb_register_blocks( 'advanced-info-card' );
	gtb_register_blocks( 'table' );
	gtb_register_blocks( 'table-row' );

}
add_action( 'init', 'wt_blocks' );

/**
 * Plugin Support Link 
 */

function gtb_support_link( $links ) {
	$gts_settings = array(
		'<a href="'. esc_url( 'https://about.me/zakaria_binsaifullah' ) .'" target="_blank" style="color: green; font-weight: bold">Get Support</a>',
	);
	return array_merge( $gts_settings, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'gtb_support_link' );

